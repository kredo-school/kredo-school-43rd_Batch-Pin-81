<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Feature extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'features_name',
    ];

    public function restaurants()
    {
        return $this->belongsToMany(
            Restaurant::class,
            'feature_restaurant'
        );
    }
}

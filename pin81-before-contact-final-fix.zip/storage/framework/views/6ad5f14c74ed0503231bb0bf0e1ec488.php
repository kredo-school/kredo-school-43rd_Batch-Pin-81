<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="mb-4">Notifications</h2>

<?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<button
    type="button"
    class="notification-item"
    data-bs-toggle="modal"
    data-bs-target="#notificationModal-<?php echo e($notification->id); ?>">

    <div class="notification-content px-4">

        <div class="d-flex justify-content-between align-items-center">

            <h5 class="mb-1">
                <?php echo e($notification->data['restaurant_name']); ?>

            </h5>

            <span class="status-badge ms-auto
                <?php if($notification->restaurant_status === \App\Models\Restaurant::STATUS_PENDING): ?>
                    status-pending
                <?php elseif($notification->restaurant_status === \App\Models\Restaurant::STATUS_APPROVED): ?>
                    status-approved
                <?php elseif($notification->restaurant_status === \App\Models\Restaurant::STATUS_REJECTED): ?>
                    status-rejected
                <?php elseif($notification->restaurant_status === \App\Models\Restaurant::STATUS_SUSPENDED): ?>
                    status-suspended
                <?php endif; ?>">
                <?php echo e(ucfirst($notification->restaurant_status)); ?>

            </span>

        </div>

        <div class="d-flex justify-content-between align-items-center">

            <p class="mb-2 text-muted">
                <?php echo e($notification->data['message']); ?>

            </p>

            <small class="text-muted">
                    <?php echo e($notification->created_at->diffForHumans()); ?>

            </small>

        </div>

    </div>

</button>

<?php echo $__env->make('admin.modals.notification_details', [
    'notification' => $notification
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <div class="alert alert-secondary text-center" style="margin-top: 70px">
        No notifications found.
    </div>

<?php endif; ?>

<style>

.notification-item{

    width:100%;

    display:flex;
    align-items:flex-start;

    gap:20px;

    padding:20px;

    border:1px solid #e9ecef;
    border-radius:14px;

    background:#fff;

    margin-bottom:15px;

    transition:.2s;

    text-align:left;
}

.notification-item:hover{
    transform: translateY(-2px);
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15);
}

.notification-content{

    flex:1;
}

.notification-item h5{

    font-weight:600;
}

.notification-item p{

    margin-bottom:0;
}

.status-badge{
    display: inline-block;
    padding: 6px 12px;
    border-radius: 999px;
    font-size: 0.85rem;
    font-weight: 600;
}

.status-pending{
    background: #dbeafe;
    color: #2563eb;
}

/* Approved */
.status-approved{
    background:#dcffd5;
    color:#5dea0c;
}

/* Rejected */
.status-rejected{
    background: #f3e8ff;
    color: #9333ea;
}

/* Suspended */
.status-suspended{
    background:#fee2e2;
    color:#dc2626;
}
</style>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/admin/notifications/index.blade.php ENDPATH**/ ?>
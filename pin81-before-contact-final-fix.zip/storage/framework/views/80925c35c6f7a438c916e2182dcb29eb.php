<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .text-navy {
            color: #0a2540;
        }
</style>

<div class="container-fluid py-4 px-5">
    
    <!-- ページタイトル -->
    <h2 class="mb-4 text-navy font-weight-bold">Review Management</h2>

    <!-- 1. 指示書デザインを反映したタブメニュー -->
    <div class="p-2 rounded-3 mb-4" style="background-color: #dbe1e8;">
        <ul class="nav nav-pills gap-1 align-items-center">
            <li class="nav-item">
                <a class="nav-link px-3 py-1 text-navy d-flex align-items-center gap-1 <?php echo e($currentTab === 'all' ? 'bg-white text-navy shadow-sm fw-bold' : ''); ?>" 
                   style="border-radius: 6px; border: 1px solid <?php echo e($currentTab === 'all' ? '#ccc' : 'transparent'); ?>;"
                   href="<?php echo e(route('admin.reviews', ['tab' => 'all'])); ?>">
                    All <span class="badge bg-secondary text-white ms-1" style="border-radius: 4px;"><?php echo e($counts['all'] ?? 0); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link px-3 py-1 text-navy d-flex align-items-center gap-1 <?php echo e($currentTab === 'visible' ? 'bg-white text-navy shadow-sm fw-bold' : ''); ?>" 
                   style="border-radius: 6px; border: 1px solid <?php echo e($currentTab === 'visible' ? '#ccc' : 'transparent'); ?>;"
                   href="<?php echo e(route('admin.reviews', ['tab' => 'visible'])); ?>">
                    Visible <span class="badge bg-success text-white ms-1" style="border-radius: 4px;"><?php echo e($counts['visible'] ?? 0); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link px-3 py-1 text-navy d-flex align-items-center gap-1 <?php echo e($currentTab === 'hidden' ? 'bg-white text-navy shadow-sm fw-bold' : ''); ?>" 
                   style="border-radius: 6px; border: 1px solid <?php echo e($currentTab === 'hidden' ? '#ccc' : 'transparent'); ?>;"
                   href="<?php echo e(route('admin.reviews', ['tab' => 'hidden'])); ?>">
                    Hidden <span class="badge bg-warning text-navy ms-1" style="border-radius: 4px;"><?php echo e($counts['hidden'] ?? 0); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link px-3 py-1 text-navy d-flex align-items-center gap-1 <?php echo e($currentTab === 'reported' ? 'bg-white text-navy shadow-sm fw-bold' : ''); ?>" 
                   style="border-radius: 6px; border: 1px solid <?php echo e($currentTab === 'reported' ? '#ccc' : 'transparent'); ?>;"
                   href="<?php echo e(route('admin.reviews', ['tab' => 'reported'])); ?>">
                    Reported <span class="badge bg-danger text-white ms-1" style="border-radius: 4px;"><?php echo e($counts['reported'] ?? 0); ?></span>
                </a>
            </li>
        </ul>
    </div>

    <!-- フラッシュメッセージ -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- 2. 全要素を網羅した融合型レビューテーブル -->
    <div class="table-responsive bg-white shadow-sm rounded-3">
        <table class="table table-hover align-middle mb-0" style="min-width: 1100px;">
            <thead class="table-light text-secondary small text-uppercase">
                <tr>
                    <th class="py-3 px-4" style="width: 12%;">Name</th>
                    <th class="py-3" style="width: 15%;">Restaurant</th>
                    <th class="py-3" style="width: 10%;">Date</th>
                    <th class="py-3" style="width: 10%;">Rating</th>
                    <th class="py-3" style="width: 23%;">Comment</th>
                    <th class="py-3" style="width: 8%;">Image</th>
                    <th class="py-3 text-center" style="width: 8%;">Status</th>
                    <th class="py-3 text-end px-4" style="width: 14%;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <!-- 通報(Reported)されている行は、指示書通りの薄い赤背景(#fff0f0)にする -->
                    <tr style="<?php echo e($review->is_reported ? 'background-color: #fff0f0;' : ''); ?>">
                        
                        <!-- Name -->
                        <td class="py-3 px-4 fw-semibold text-navy">
                            <?php echo e(optional($review->user)->name ?? 'Unknown User'); ?>

                        </td>
                        
                        <!-- Restaurant -->
                        <td class="py-3 text-secondary">
                            <?php echo e(optional($review->restaurant)->name ?? 'N/A'); ?>

                        </td>
                        
                        <!-- Date -->
                        <td class="py-3 text-secondary small">
                            <?php echo e($review->created_at->format('Y-m-d')); ?>

                        </td>
                        
                        <!-- Rating -->
                        <td class="py-3 text-warning">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <i class="fa-<?php echo e($i <= (optional($review->star)->rating ?? 0) ? 'solid' : 'regular'); ?> fa-star"></i>
                            <?php endfor; ?>
                        </td>
                        
                        <!-- Comment -->
                        <td class="py-3">
                            <?php if($review->is_reported): ?>
                                <div class="text-danger small fw-bold mb-1">
                                    <i class="fa-solid fa-triangle-exclamation"></i> Reported by restaurant
                                </div>
                            <?php endif; ?>
                            <div class="text-navy small text-wrap" style="max-height: 60px; overflow-y: auto; line-height: 1.5;">
                                <?php echo e($review->description); ?>

                            </div>
                        </td>
                        
                        <!-- Image -->
                        <td class="py-3">
                            <?php if($review->image): ?>
                                <img src="<?php echo e(asset($review->image)); ?>" class="rounded border shadow-sm" style="width: 50px; height: 50px; object-fit: cover;" alt="Review">
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-center bg-light text-muted rounded border" style="width: 50px; height: 50px;">
                                    <i class="fa-regular fa-image fs-5"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        
                        <!-- Status -->
                        <td class="py-3 text-center">
                            <?php if(($review->status ?? 'visible') === 'visible'): ?>
                                <span class="badge px-3 py-1.5 text-success bg-success-subtle border border-success-subtle rounded-pill fw-semibold" style="background-color: #e6f7ed; color: #1f9254;">visible</span>
                            <?php else: ?>
                                <span class="badge px-3 py-1.5 text-secondary bg-secondary-subtle border border-secondary-subtle rounded-pill fw-semibold" style="background-color: #f1f3f5; color: #6c757d;">hidden</span>
                            <?php endif; ?>
                        </td>
                        
                        <!-- Actions -->
                        <td class="py-3 text-end px-4">
                            <div class="d-flex justify-content-end align-items-center gap-1.5">
                                
                                <!-- Show / Hide 切り替え -->
                                <form action="<?php echo e(route('admin.reviews.toggle', $review->id)); ?>" method="POST" class="d-inline mb-0">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <?php if(($review->status ?? 'visible') === 'visible'): ?>
                                        <button type="submit" class="btn btn-outline-secondary btn-sm px-2.5 py-1 bg-white rounded shadow-sm text-navy border-secondary-subtle">
                                            Hide
                                        </button>
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-outline-secondary btn-sm px-2.5 py-1 bg-white rounded shadow-sm text-dark border-secondary-subtle">
                                            Show
                                        </button>
                                    <?php endif; ?>
                                </form>

                                <!-- 通報されている場合のみ横に表示されるアクション -->
                                <?php if($review->is_reported): ?>
                                    <button type="button" class="btn btn-outline-danger btn-sm px-2.5 py-1 bg-white rounded shadow-sm text-danger border-danger-subtle ms-1">
                                        Dismiss Report
                                    </button>
                                    <button type="button" class="btn btn-danger btn-sm px-2.5 py-1 rounded shadow-sm text-white ms-1">
                                        Remove Review
                                    </button>
                                <?php endif; ?>

                            </div>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="fa-regular fa-folder-open d-block fs-3 mb-2"></i>
                            No reviews found in this section.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/admin/reviews/index.blade.php ENDPATH**/ ?>
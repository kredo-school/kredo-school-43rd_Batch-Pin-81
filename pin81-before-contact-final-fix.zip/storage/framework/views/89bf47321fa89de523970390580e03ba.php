<div class="modal fade"
     id="deleteModal<?php echo e($id); ?>"
     tabindex="-1">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">
                    Delete <?php echo e($type ?? 'Item'); ?>

                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                </button>
            </div>

            <div class="modal-body">
                <strong><?php echo e($message); ?></strong>
            </div>

            <div class="modal-footer">

                <button type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <form action="<?php echo e($route); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit"
                            class="btn btn-danger">
                        Delete
                    </button>

                </form>

            </div>

        </div>
    </div>
</div><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/admin/modals/delete.blade.php ENDPATH**/ ?>
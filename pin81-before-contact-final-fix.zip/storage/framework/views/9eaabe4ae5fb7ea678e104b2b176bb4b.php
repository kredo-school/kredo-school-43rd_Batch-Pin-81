<?php $__env->startSection('title', 'Restaurants'); ?>

<?php $__env->startSection('content'); ?>

<style>
.page-title{
    color:#0a2540;
    font-size:48px;
    font-weight:700;
}

.btn-dark-blue{
    background-color: #0a2540;
    color: #fff !important;
}

.btn-dark-blue:hover{
    background-color:#0a2540;
    color:#fff !important;
}

.btn-unactive {
    background: #fff;
    color: #0a2540;
    border: 1px solid #0a2540;
}

.btn-unactive:hover{
    background-color: #0a2540;
    color: #fff !important;
}

.btn-dark-blue:active,
.btn-dark-blue.active,
.btn-dark-blue:focus,
.btn-dark-blue:focus-visible {
    background-color: #0a2540 !important;
    color: #fff !important;
    border-color: #0a2540 !important;
    box-shadow: none !important;
}

.btn-unactive:active,
.btn-unactive.active {
    background-color: #0a2540 !important;
    color: #fff !important;
    border-color: #0a2540 !important;
}
.table th{
    font-size:13px;
    color:#6b7280;
    padding:1rem 1.5rem;
}

.table td{
    padding:1rem 1.5rem;
}

/* Pending */
.status-pending{
    background: #dbeafe;
    color: #2563eb;
}

/* Active */
.status-active{
    background:#dcffd5;
    color:#5dea0c;
}

/* Reject */
.status-rejected{
    background: #f3e8ff;
    color: #9333ea;
}

/* Suspended */
.status-suspended{
    background:#fee2e2;
    color:#dc2626;
}

.status-pending,
.status-active,
.status-rejected,
.status-suspended{
    border: none;
    padding: .5rem .75rem;
    border-radius: 999px;
}

.dropdown-menu{
    border: none;
    border-radius: 16px;
    padding: .5rem;
    min-width: 180px;
    box-shadow: 0 8px 24px rgba(0,0,0,.08);
}

.status-option{
    display: block;
    width: 100%;
    text-align: left;
    border: none;
    background: transparent;
    padding: .6rem .8rem;
    border-radius: 10px;
    font-weight: 500;
}

/* Pending */
.status-option-pending{
    color: #2563eb;
}

.status-option-pending:hover{
    background: #dbeafe;
    color: #2563eb;
}

/* active */
.status-option-active{
    color:#16a34a;
}

.status-option-active:hover{
    background:#dcffd5;
    color:#16a34a;
}

/* Admin */
.status-option-rejected{
    color: #9333ea;
}

.status-option-rejected:hover{
    background: #f3e8ff;
    color: #9333ea;
}

.status-option-suspended{
    color:#dc2626;
}

.status-option-suspended:hover{
    background:#fee2e2;
    color:#dc2626;
}

/* Modal style */
.modal-content{
    border-radius: 20px;
    border: none;
}

.modal-header{
    border-bottom: 1px solid #e5e7eb;
}

.modal-footer{
    border-top: 1px solid #e5e7eb;
}

</style>

<h1 class="fw-bold mb-4 page-title">
    Restaurants
</h1>

<div class="mb-4">
    <a href="<?php echo e(route('admin.restaurants')); ?>" class="btn <?php echo e(request()->routeIs('admin.restaurants') ? 'btn-dark-blue' : 'btn-unactive'); ?> me-2">All</a>
    <a href="<?php echo e(route('admin.restaurants.pending')); ?>" class="btn <?php echo e(request()->routeIs('admin.restaurants.pending') ? 'btn-dark-blue' : 'btn-unactive'); ?> me-2">Pending</a>
    <a href="<?php echo e(route('admin.restaurants.active')); ?>" class="btn <?php echo e(request()->routeIs('admin.restaurants.active') ? 'btn-dark-blue' : 'btn-unactive'); ?> me-2">Active</a>
    <a href="<?php echo e(route('admin.restaurants.rejected')); ?>" class="btn <?php echo e(request()->routeIs('admin.restaurants.rejected') ? 'btn-dark-blue' : 'btn-unactive'); ?>">Rejected</a>
    <a href="<?php echo e(route('admin.restaurants.suspended')); ?>" class="btn <?php echo e(request()->routeIs('admin.restaurants.suspended') ? 'btn-dark-blue' : 'btn-unactive'); ?>">Suspended</a>
</div>

<div class="card border-0 shadow-sm rounded-4">

    <div class="table-responsive">

        <table class="table align-middle mb-0">

            <thead>
                <tr>
                    <th>RESTAURANT</th>
                    <th>OWNER</th>
                    <th>LOCATION</th>
                    <th>CATEGORY</th>
                    <th>STATUS</th>
                    <th></th>
                </tr>
                </thead>

                <tbody>

                  <?php $__empty_1 = true; $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                      <td>
                          <div class="d-flex align-items-center">

                              <div>
                                  <strong>
                                      <?php echo e($restaurant->restaurant_name); ?>

                                  </strong>

                                  <div class="small text-secondary">
                                      <?php echo e($restaurant->user->email); ?>

                                  </div>
                              </div>

                          </div>
                      </td>

                      <td><?php echo e($restaurant->owner_name); ?></td>
                      <td><?php echo e($restaurant->address); ?></td>
                      <td><?php echo e($restaurant->category ?? '-'); ?></td>

                      <td>
                          <div class="dropdown">

                              <button
                                  type="button"
                                  class="badge border-0 dropdown-toggle

                                  <?php if($restaurant->status == 'pending'): ?>
                                      status-pending
                                  <?php elseif($restaurant->status == 'approved'): ?>
                                      status-active
                                  <?php elseif($restaurant->status == 'rejected'): ?>
                                      status-rejected
                                  <?php else: ?>
                                      status-suspended
                                  <?php endif; ?>"

                                  data-bs-toggle="dropdown">

                                  <?php echo e(ucfirst($restaurant->status)); ?>


                              </button>

                                <ul class="dropdown-menu">

                                    <li>
                                        <form action="<?php echo e(route('admin.restaurants.status', $restaurant)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>

                                            <input type="hidden" name="status" value="pending">

                                            <button type="submit"
                                                    class="status-option status-option-pending d-flex justify-content-between">

                                                <span>Pending</span>

                                                <?php if($restaurant->status == 'pending'): ?>
                                                    <span>✓</span>
                                                <?php endif; ?>

                                            </button>
                                        </form>
                                    </li>

                                    <li>
                                        <form action="<?php echo e(route('admin.restaurants.status', $restaurant)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>

                                            <input type="hidden" name="status" value="active">

                                            <button type="submit"
                                                    class="status-option status-option-active d-flex justify-content-between">

                                                <span>Active</span>

                                                <?php if($restaurant->status == 'active'): ?>
                                                    <span>✓</span>
                                                <?php endif; ?>

                                            </button>
                                        </form>
                                    </li>

                                    <li>
                                        <form action="<?php echo e(route('admin.restaurants.status', $restaurant)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>

                                            <input type="hidden" name="status" value="rejected">

                                            <button type="submit"
                                                    class="status-option status-option-rejected d-flex justify-content-between">

                                                <span>Rejected</span>

                                                <?php if($restaurant->status == 'rejected'): ?>
                                                    <span>✓</span>
                                                <?php endif; ?>

                                            </button>
                                        </form>
                                    </li>

                                    <li>
                                        <form action="<?php echo e(route('admin.restaurants.status', $restaurant)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>

                                            <input type="hidden" name="status" value="suspended">

                                            <button type="submit"
                                                    class="status-option status-option-suspended d-flex justify-content-between">

                                                <span>Suspended</span>

                                                <?php if($restaurant->status == 'suspended'): ?>
                                                    <span>✓</span>
                                                <?php endif; ?>

                                            </button>
                                        </form>
                                    </li>

                                </ul>

                          </div>

                      </td>

                      <td>
                            <a href="<?php echo e(route('admin.restaurants.show', $restaurant)); ?>"
                            class="btn text-secondary border-0">
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </a>

                            <button type="button"
                                    class="btn text-danger border-0"
                                    data-bs-toggle="modal"
                                    data-bs-target="#deleteModal<?php echo e($restaurant->id); ?>">
                                <i class="fa-regular fa-trash-can"></i>
                            </button>

                      </td>

                    </tr>

                    
                    <?php echo $__env->make('admin.modals.delete', [
                        'id' => $restaurant->id,
                        'route' => route('admin.restaurants.destroy', $restaurant),
                        'title' => 'Delete Restaurant',
                        'message' => 'Are you sure you want to delete ' . $restaurant->restaurant_name . '?'
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="6" class="text-center py-4">
                            No restaurants found.
                        </td>

                    </tr>

                    <?php endif; ?>
                </tbody>
            
            </table>

    </div>

</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/admin/restaurants/index.blade.php ENDPATH**/ ?>
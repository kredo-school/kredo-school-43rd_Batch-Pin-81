<?php $__env->startSection('title', 'Contact Management'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .contact-tab {
            color: #0a2540;
            border: 1px solid transparent;
        }

        .contact-tab.active {
            background-color: #ffffff;
            border-color: #c8d0d8;
            box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075);
            font-weight: 700;
        }

        .contact-list-item {
            color: #0a2540;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
        }

        .contact-list-item.active,
        .contact-list-item:hover {
            background-color: #f1f5f9;
            border-color: #0a2540;
        }

        .message-bubble {
            max-width: 78%;
            border-radius: 14px;
            padding: 1rem;
        }

        .message-admin {
            align-self: flex-end;
            background-color: #0a2540;
            color: #ffffff;
        }

        .message-user {
            align-self: flex-start;
            background-color: #ffffff;
            border: 1px solid #e5e7eb;
            color: #0a2540;
        }
    </style>

    <div class="container-fluid py-4 px-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-1" style="color: #0a2540;">Contact Management</h2>
                <p class="text-muted mb-0">Manage inquiries from customers and restaurants.</p>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-12 col-xl-4">
                <div class="bg-white rounded-4 shadow-sm p-3">
                    <div class="p-2 rounded-3 mb-3" style="background-color: #dbe1e8;">
                        <div class="nav nav-pills gap-1">
                            <a class="nav-link contact-tab px-3 py-2 <?php echo e($currentTab === 'all' ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.contacts.index', ['tab' => 'all', 'status' => $currentStatus])); ?>">
                                All <span class="badge bg-secondary ms-1"><?php echo e($counts['all']); ?></span>
                            </a>
                            <a class="nav-link contact-tab px-3 py-2 <?php echo e($currentTab === 'customer' ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.contacts.index', ['tab' => 'customer', 'status' => $currentStatus])); ?>">
                                Customer <span class="badge bg-secondary ms-1"><?php echo e($counts['customer']); ?></span>
                            </a>
                            <a class="nav-link contact-tab px-3 py-2 <?php echo e($currentTab === 'restaurant' ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.contacts.index', ['tab' => 'restaurant', 'status' => $currentStatus])); ?>">
                                Restaurant <span class="badge bg-secondary ms-1"><?php echo e($counts['restaurant']); ?></span>
                            </a>
                        </div>
                    </div>

                    <div class="d-flex gap-2 mb-3">
                        <a class="btn btn-sm <?php echo e($currentStatus === 'all' ? 'btn-dark' : 'btn-outline-dark'); ?>"
                            href="<?php echo e(route('admin.contacts.index', ['tab' => $currentTab, 'status' => 'all'])); ?>">All</a>
                        <a class="btn btn-sm <?php echo e($currentStatus === 'open' ? 'btn-dark' : 'btn-outline-dark'); ?>"
                            href="<?php echo e(route('admin.contacts.index', ['tab' => $currentTab, 'status' => 'open'])); ?>">Open
                            <?php echo e($counts['open']); ?></a>
                        <a class="btn btn-sm <?php echo e($currentStatus === 'replied' ? 'btn-dark' : 'btn-outline-dark'); ?>"
                            href="<?php echo e(route('admin.contacts.index', ['tab' => $currentTab, 'status' => 'replied'])); ?>">Replied
                            <?php echo e($counts['replied']); ?></a>
                    </div>

                    <div class="d-flex flex-column gap-2">
                        <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a class="contact-list-item text-decoration-none p-3 <?php echo e($selectedContact?->id === $contact->id ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.contacts.index', ['tab' => $currentTab, 'status' => $currentStatus, 'contact' => $contact->id])); ?>">
                                <div class="d-flex justify-content-between align-items-start gap-2">
                                    <div class="fw-bold text-truncate">
                                        <?php echo e($contact->title ?: Str::limit($contact->message, 36)); ?>

                                    </div>
                                    <span
                                        class="badge <?php echo e($contact->status === 'open' ? 'bg-warning text-dark' : 'bg-success'); ?>">
                                        <?php echo e($contact->status); ?>

                                    </span>
                                </div>
                                <div class="small text-muted mt-1">
                                    <?php echo e($contact->inquiry_type); ?> /
                                    <?php echo e($contact->user?->full_name ?: $contact->user?->email); ?>

                                </div>
                                <div class="small text-muted mt-1">
                                    <?php echo e($contact->created_at->format('Y-m-d H:i')); ?>

                                    <?php if($contact->replies->count() > 0): ?>
                                        ・<?php echo e($contact->replies->count()); ?> replies
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center text-muted py-5">
                                No contacts found.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-12 col-xl-8">
                <div class="bg-white rounded-4 shadow-sm p-4 min-vh-75">
                    <?php if(!$selectedContact): ?>
                        <div class="text-center text-muted py-5">
                            <i class="fa-regular fa-message fs-1 mb-3"></i>
                            <h5 class="fw-bold">Select a message to reply.</h5>
                            <p class="mb-0">Choose a contact from the list on the left.</p>
                        </div>
                    <?php else: ?>
                        <div class="d-flex justify-content-between align-items-start gap-3 border-bottom pb-3 mb-4">
                            <div>
                                <div class="d-flex gap-2 align-items-center mb-2">
                                    <span class="badge bg-primary"><?php echo e($selectedContact->inquiry_type); ?></span>
                                    <span
                                        class="badge <?php echo e($selectedContact->status === 'open' ? 'bg-warning text-dark' : 'bg-success'); ?>">
                                        <?php echo e($selectedContact->status); ?>

                                    </span>
                                </div>
                                <h4 class="fw-bold mb-1" style="color: #0a2540;">
                                    <?php echo e($selectedContact->title ?: 'Inquiry #' . $selectedContact->id); ?>

                                </h4>
                                <div class="text-muted small">
                                    From: <?php echo e($selectedContact->user?->full_name ?: $selectedContact->user?->email); ?>

                                    <?php if($selectedContact->restaurant): ?>
                                        / <?php echo e($selectedContact->restaurant->restaurant_name); ?>

                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="d-flex gap-2">
                                <form action="<?php echo e(route('admin.contacts.status', $selectedContact)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status"
                                        value="<?php echo e($selectedContact->status === 'open' ? 'replied' : 'open'); ?>">
                                    <button type="submit" class="btn btn-outline-dark btn-sm">
                                        Mark as <?php echo e($selectedContact->status === 'open' ? 'replied' : 'open'); ?>

                                    </button>
                                </form>

                                <form action="<?php echo e(route('admin.contacts.destroy', $selectedContact)); ?>" method="POST"
                                    onsubmit="return confirm('Delete this contact thread?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                </form>
                            </div>
                        </div>

                        <div class="d-flex flex-column gap-3 mb-4" style="max-height: 520px; overflow-y: auto;">
                            <?php
                                $messages = collect([$selectedContact])->merge($selectedContact->replies);
                            ?>

                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isAdmin = $message->user?->isAdmin();
                                    $attachments = is_array($message->attachments)
                                        ? $message->attachments
                                        : (json_decode($message->attachments ?? '[]', true) ?:
                                        []);
                                ?>

                                <div class="message-bubble <?php echo e($isAdmin ? 'message-admin' : 'message-user'); ?>">
                                    <div class="small fw-bold mb-2">
                                        <?php echo e($message->sender_label); ?>

                                        <span
                                            class="fw-normal opacity-75 ms-2"><?php echo e($message->created_at->format('Y-m-d H:i')); ?></span>
                                    </div>
                                    <div style="white-space: pre-wrap;"><?php echo e($message->message); ?></div>

                                    <?php if(!empty($attachments)): ?>
                                        <div class="d-flex flex-wrap gap-2 mt-3">
                                            <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!empty($path) && is_string($path)): ?>
                                                    <a href="<?php echo e(asset('storage/' . $path)); ?>" target="_blank">
                                                        <img src="<?php echo e(asset('storage/' . $path)); ?>" class="img-thumbnail"
                                                            style="max-width: 140px; max-height: 140px; object-fit: cover;"
                                                            alt="Attachment">
                                                    </a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <form action="<?php echo e(route('admin.contacts.reply', $selectedContact)); ?>" method="POST"
                            enctype="multipart/form-data" class="border-top pt-4">
                            <?php echo csrf_field(); ?>
                            <label for="admin-reply-message" class="form-label fw-bold">Reply</label>
                            <textarea id="admin-reply-message" name="message" class="form-control mb-3" rows="4"
                                placeholder="Type your reply..." required><?php echo e(old('message')); ?></textarea>

                            <div class="d-flex justify-content-between align-items-center gap-3">
                                <input type="file" name="attachments[]" class="form-control" multiple accept="image/*">
                                <button type="submit" class="btn btn-dark px-4">
                                    <i class="fa-solid fa-paper-plane me-2"></i>Send Reply
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/admin/contacts/index.blade.php ENDPATH**/ ?>
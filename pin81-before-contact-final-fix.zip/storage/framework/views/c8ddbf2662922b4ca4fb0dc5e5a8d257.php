<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center align-items-center min-vh-100" style="font-family: inter">
    
    <div class="col-12 col-md-10 col-lg-5">

        <!-- Login Card -->
        <div class="card p-4 shadow-sm border-0 signup-card bg-white" style="max-width: 600px; width: 100%; border-radius: 16px;">
            <div class="card-body p-4">
                <h3 class="card-title fw-bold mb-1 text-center mb-2" style="color: #0a2540;"><?php echo e(__('Login')); ?></h3>
                <p class="text-muted small mb-4 text-center">Access your account to make reservations or  manage your restaurant</p>

                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <!-- Email Field -->
                    <div class="mb-3">
                        <label for="email" class="form-label fw-semibold" style="color: #0a2540;"><?php echo e(__('Email')); ?></label>
                            <input id="email" type="email" class="form-control input-box <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="your@email.com" required autocomplete="email" autofocus>
                            
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Password Field -->
                    <div class="mb-3">
                        <label for="password" class="form-label fw-semibold" style="color: #0a2540;"><?php echo e(__('Password')); ?></label>
                            <input id="password" type="password" class="form-control input-box <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="••••••••" required autocomplete="current-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Remember and Forgot Password -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input custom-checkbox" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="remember">
                                <?php echo e(__('Remember me')); ?>

                            </label>
                        </div>
                        <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Forgot password?')); ?>

                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- Login Button -->
                    <button type="submit" class="btn w-100 fw-semibold mb-3 custom-btn-a">
                        <?php echo e(__('Login')); ?>

                    </button>

                    <!-- Guest Login Button -->
                    <a href="<?php echo e(route('customer.search')); ?>" class="btn w-100 fw-semibold mb-3 custom-btn-b">
                        <?php echo e(__('Continue as a Guest')); ?>

                    </a>

                    <!-- Sign Up Link -->
                    <p class="text-center text-muted small mb-3">
                        <?php echo e(__("Don't have an account?")); ?> <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Sign up')); ?></a>
                    </p>

                    <!-- Partner Link -->
                    <p class="text-center">
                        <a href="#"><?php echo e(__('Partner with us')); ?></a>
                    </p>
                </form>
            </div>
        </div>

        <!-- Back to Home -->
        
    </div>
</div>

<style>
    .min-vh-100 {
        min-height: 100vh;
    }

    .card{
        width: 100%;
        max-width: 500px;
        margin: 0 auto;
        border: none;
        border-radius: 10px;
    }
    
    .input-box:focus {
        border-color: #cfb2c4;
        box-shadow: 0 0 0 0.2rem rgba(233, 192, 228, 0.25);
    }
    
    .custom-checkbox:checked {
        color: #0a2540;
        background-color: #8d4b75;
        border-color: #ca9cb9;
    }

    .custom-checkbox:focus {
        box-shadow: 0 0 0 0.2rem rgba(233, 192, 228, 0.25);
        border-color: #ca9cb9;
    }

    /* Login button */
    .custom-btn-a {
        background-color: #FCE7F3;
        color: #0a2540; /* text color */
        cursor: pointer;
        transition: 0.3s;
    }

    /* mouse hover effect */
    .custom-btn-a:hover {
        background-color: #fdd6eb;
        color: #0a2a5e;
    }

    /* login as a guest button */
    .custom-btn-b {
        background-color: transparent;
        color: #0a2540; /* text color */
        border: 1px solid #0a2540;
        cursor: pointer;
        transition: 0.3s;
    }

    /* mouse hover effect */
    .custom-btn-b:hover {
        background-color: #0a2540;
        color: white;
        border-color: #0a2540;
        text-decoration: none; 
    }

    /* Link decorations */
    a{
        color: #0a2540;
        font-weight: 600;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/auth/login.blade.php ENDPATH**/ ?>
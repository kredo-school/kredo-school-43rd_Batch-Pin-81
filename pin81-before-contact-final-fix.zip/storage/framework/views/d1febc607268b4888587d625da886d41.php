<?php $__env->startSection('title', 'Restaurants'); ?>

<?php $__env->startSection('content'); ?>

<div class="container bg-light"> 
    
    <div class="mb-3 filter-bar d-none d-md-block bg-white">

        <div class="d-flex justify-content-between align-items-center mb-2">
            <h5 class="h4 fw-bold" style="color: #0a2540;">
                <?php echo e($restaurants->count()); ?> Restaurants Found
            </h5>

            <button class="btn filter-btn ms-3 flex-shrink-0"
                    data-bs-toggle="modal"
                    data-bs-target="#filterModal">
                    <i class="fa-solid fa-sliders"></i> Filters
            </button>
        </div>

        
        <div id="activeFilters" class="d-flex gap-2 flex-wrap justify-content-end">

            <?php $__currentLoopData = request('cuisines', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuisine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge bg-light border text-secondary fs-6 px-2 pt-2" style="height: 2rem">
                    <?php echo e($cuisine); ?>

                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = request('features', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge bg-light border text-secondary fs-6 px-2 pt-2" style="height: 2rem">
                    <?php echo e($feature); ?>

                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(request('rating')): ?>
                <span class="badge bg-light border text-secondary fs-6 px-2 pt-2" style="height: 2rem">
                    At least <?php echo e(request('rating')); ?> stars
                </span>
            <?php endif; ?>
            
            <?php if(request('distance')): ?>
                <span class="badge bg-light border text-secondary fs-6 px-2 pt-2" style="height: 2rem">
                    <?php echo e(request('distance')); ?>

                </span>
            <?php endif; ?>

        </div>
    </div>

    
    <div class="d-flex justify-content-between align-items-center mb-3 d-md-none">
        <div>
            <h5 class="mb-0">125 Restaurants Found</h5>
        </div>

        <button
            class="btn filter-btn rounded-pill"
            data-bs-toggle="modal"
            data-bs-target="#filterModal">
            <i class="bi bi-sliders"></i>
        </button>
    </div>

    
    <div class="row g-4">
        <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-6 col-lg-4">
               <?php echo $__env->make('customers.restaurants.partials.card', ['restaurant' => $restaurant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<style>
    .filter-bar{
        position: sticky;
        top: 50px;
        z-index: 100;
        padding: 12px 0;
        --bs-bg-opacity: .9;
        border-radius: 10px;
    }

    .filter-btn{
        background-color: transparent;
        color: #0a2540; /* text color */
        border: 2px solid #0a2540;
        font-weight: 600;
        cursor: pointer;
        transition: 0.3s;
    }

    .filter-btn:hover{
        background-color: #0a2540;
        color: #fff;
    }

</style>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('customers.restaurants.partials.modals.filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
               
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/customers/restaurants/index.blade.php ENDPATH**/ ?>
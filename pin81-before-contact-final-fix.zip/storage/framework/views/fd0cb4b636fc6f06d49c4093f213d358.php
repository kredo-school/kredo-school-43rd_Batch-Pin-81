<?php $__env->startSection('title', 'Table Schedule'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $displayDate = \Carbon\Carbon::parse($date);
        $blockMinutes = (int) (($restaurant->stay_duration ?? 120) + 15);
        $slotMinutes = (int) ($restaurant->stay_duration ?? 120);
        $totalColumns = count($timeSlots);
        $currentStart = $displayStartTime ?? ($timelineOpen ?? '17:00');
        $showingEnd = $currentStart
            ? \Carbon\Carbon::createFromFormat('H:i', $currentStart)
                ->addMinutes(max($totalColumns - 1, 0) * 15)
                ->format('H:i')
            : null;
        $prevStart = $currentStart
            ? \Carbon\Carbon::createFromFormat('H:i', $currentStart)->subMinutes(30)->format('H:i')
            : null;
        $nextStart = $currentStart
            ? \Carbon\Carbon::createFromFormat('H:i', $currentStart)->addMinutes(30)->format('H:i')
            : null;

        $fullName = function ($reservation) {
            $name = trim(($reservation->user->first_name ?? '') . ' ' . ($reservation->user->last_name ?? ''));
            return $name !== '' ? $name : 'Guest';
        };

        $statusBadgeClass = function ($status) {
            return match ($status) {
                'pending' => 'bg-light text-navy border',
                'confirmed' => 'bg-navy text-white',
                'completed' => 'bg-pink text-navy',
                'cancelled' => 'bg-danger-subtle text-danger border',
                default => 'bg-light text-secondary border',
            };
        };

        $reservationBlockClass = function ($status) {
            return match ($status) {
                'pending' => 'reservation-block-pending',
                'confirmed' => 'reservation-block-confirmed',
                'completed' => 'reservation-block-completed',
                default => 'reservation-block-pending',
            };
        };

        $cancelledByLabel = function ($reservation) {
            return $reservation->cancelled_by === 'restaurant' ? 'Canceled by restaurant' : 'Canceled by customer';
        };
    ?>

    <style>
        .text-navy {
            color: #0A2540 !important;
        }

        .bg-navy {
            background-color: #0A2540 !important;
        }

        .bg-pink {
            background-color: #FCE7F3 !important;
        }

        .btn-chevron-custom {
            background-color: transparent !important;
            border: 1px solid #e9ecef !important;
            color: #6c757d !important;
            transition: all 0.2s ease-in-out;
        }

        .btn-chevron-custom:hover {
            background-color: #FCE7F3 !important;
            border-color: #FCE7F3 !important;
            color: #0A2540 !important;
        }

        .btn-pink-custom {
            background-color: #FCE7F3 !important;
            color: #0A2540 !important;
            border: none !important;
            border-radius: 8px;
            height: 31px;
        }

        .btn-pink-custom:hover {
            background-color: #fbcfe8 !important;
        }

        .custom-table-head th {
            padding-bottom: 4px !important;
            border-bottom: none !important;
        }

        .table-clickable {
            cursor: pointer;
            transition: background-color 0.15s ease-in-out;
        }

        .table-clickable:hover {
            background-color: #f1f3f5 !important;
        }

        .schedule-table {
            table-layout: fixed !important;
            width: 100% !important;
            min-width: 800px;
            border-collapse: separate;
            border-spacing: 0 12px;
            margin-top: -12px;
        }

        .schedule-table .table-name-cell {
            width: 100px !important;
            min-width: 100px !important;
            background-color: #fff;
            border-top-left-radius: 8px;
            border-bottom-left-radius: 8px;
        }

        .schedule-table .time-cell,
        .schedule-table .time-head-cell {
            width: 60px !important;
            min-width: 60px !important;
            overflow: hidden;
            white-space: nowrap;
        }

        .reservation-block-confirmed {
            background-color: #0A2540 !important;
            color: #ffffff !important;
        }

        .reservation-block-pending {
            background-color: #e9ecef !important;
            color: #0A2540 !important;
            border: 1px solid #ced4da;
        }

        .reservation-block-completed {
            background-color: #FCE7F3 !important;
            color: #0A2540 !important;
        }

        .disabled-table {
            opacity: 0.45;
        }

        .status-badge {
            font-size: 10px;
            letter-spacing: 0.2px;
            text-transform: capitalize;
        }

        .empty-slot {
            height: 50px;
            min-width: 60px;
            padding: 0;
            background-color: #fff;
        }

        @media (max-width: 767.98px) {
            ::-webkit-scrollbar {
                display: none;
            }
        }
    </style>

    <div class="d-flex flex-column"
        style="min-height: calc(100vh - 70px); background-color: transparent; margin-top: -100px;">
        <div class="d-flex flex-column d-md-none px-4 bg-white" style="padding-top: 95px; box-sizing: border-box;">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h2 class="h4 mb-0 fw-bold text-navy">Table Schedule</h2>
                <button
                    class="btn btn-sm px-3 py-1 fw-bold d-inline-flex align-items-center justify-content-center btn-pink-custom"
                    data-bs-toggle="modal" data-bs-target="#addTableModal">
                    <i class="fa-solid fa-plus me-1"></i> Add Table
                </button>
            </div>

            <div class="d-flex align-items-center gap-2 pb-2 mt-3">
                <a href="<?php echo e(route('restaurant.dashboard', ['date' => $displayDate->copy()->subDay()->format('Y-m-d'), 'start_time' => $currentStart])); ?>"
                    class="btn btn-chevron-custom btn-sm px-2 py-1">
                    <i class="fa-solid fa-chevron-left"></i>
                </a>
                <input type="date" class="form-control form-control-sm text-center fw-bold" value="<?php echo e($date); ?>"
                    onchange="location.href='<?php echo e(route('restaurant.dashboard')); ?>?date=' + this.value + '&start_time=<?php echo e($currentStart); ?>'"
                    style="width: 100%; background-color: #f8f9fa;">
                <a href="<?php echo e(route('restaurant.dashboard', ['date' => $displayDate->copy()->addDay()->format('Y-m-d'), 'start_time' => $currentStart])); ?>"
                    class="btn btn-chevron-custom btn-sm px-2 py-1">
                    <i class="fa-solid fa-chevron-right"></i>
                </a>
            </div>
        </div>

        <div class="d-none d-md-flex justify-content-between align-items-center px-4 pb-3 bg-white"
            style="padding-top: 100px;">
            <h2 class="h4 mb-0 fw-bold text-navy">Table Schedule</h2>

            <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center gap-2">
                    <a href="<?php echo e(route('restaurant.dashboard', ['date' => $displayDate->copy()->subDay()->format('Y-m-d'), 'start_time' => $currentStart])); ?>"
                        class="btn btn-chevron-custom btn-sm px-2 py-1">
                        <i class="fa-solid fa-chevron-left"></i>
                    </a>

                    <input type="date" class="form-control form-control-sm text-center fw-bold"
                        value="<?php echo e($date); ?>"
                        onchange="location.href='<?php echo e(route('restaurant.dashboard')); ?>?date=' + this.value + '&start_time=<?php echo e($currentStart); ?>'"
                        style="width: 140px; background-color: #f8f9fa;">

                    <a href="<?php echo e(route('restaurant.dashboard', ['date' => $displayDate->copy()->addDay()->format('Y-m-d'), 'start_time' => $currentStart])); ?>"
                        class="btn btn-chevron-custom btn-sm px-2 py-1">
                        <i class="fa-solid fa-chevron-right"></i>
                    </a>
                </div>

                <button
                    class="btn btn-sm px-3 py-1 fw-bold d-inline-flex align-items-center justify-content-center btn-pink-custom"
                    data-bs-toggle="modal" data-bs-target="#addTableModal">
                    <i class="fa-solid fa-plus me-1"></i> Add Table
                </button>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success mx-4 mt-3 mb-0"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger mx-4 mt-3 mb-0"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger mx-4 mt-3 mb-0">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <div class="d-block d-md-none px-3 pt-3 pb-5">
            <div class="d-flex gap-2 overflow-x-auto pb-3 mb-3" style="scrollbar-width: none; -ms-overflow-style: none;">
                <?php $__empty_1 = true; $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('restaurant.dashboard', ['date' => $date, 'start_time' => $time])); ?>"
                        class="btn rounded-pill px-3 py-2 small <?php echo e($time === $currentStart ? 'fw-bold text-white bg-navy' : 'fw-medium'); ?> text-nowrap"
                        style="<?php echo e($time === $currentStart ? '' : 'background-color: #f1f3f5; color: #495057;'); ?> font-size: 13px;">
                        <?php echo e($time); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="text-muted small">Closed on this date.</span>
                <?php endif; ?>
            </div>

            <h5 class="fw-bold mb-3 text-navy" style="font-size: 18px;">Reservations (<?php echo e($activeReservations->count()); ?>)
            </h5>
            <div class="d-flex flex-column gap-3 mb-4">
                <?php $__empty_1 = true; $__currentLoopData = $activeReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $customer = $fullName($reservation);
                        $time = \Carbon\Carbon::parse($reservation->reservation_time)->format('H:i');
                        $tableName = $reservation->table->table_name ?? '-';
                    ?>
                    <div class="card p-3 border rounded-4 shadow-sm" style="background-color: #ffffff; cursor: pointer;"
                        onclick="openReservationModal(<?php echo e($reservation->id); ?>, 'RM<?php echo e(str_pad($reservation->id, 3, '0', STR_PAD_LEFT)); ?>', <?php echo e(\Illuminate\Support\Js::from($customer)); ?>, '<?php echo e($time); ?>', <?php echo e(\Illuminate\Support\Js::from($durationLabel)); ?>, <?php echo e($reservation->num_of_people); ?>, <?php echo e(\Illuminate\Support\Js::from($tableName)); ?>, '<?php echo e($reservation->status); ?>')">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <div class="fw-bold text-dark" style="font-size: 15px;"><?php echo e($customer); ?></div>
                            <span class="badge text-secondary border bg-light px-2 py-1 rounded small fw-normal"
                                style="font-size: 10px;">
                                RM<?php echo e(str_pad($reservation->id, 3, '0', STR_PAD_LEFT)); ?>

                            </span>
                        </div>
                        <div class="text-secondary small d-flex flex-column gap-1" style="font-size: 12px;">
                            <div><i class="fa-regular fa-clock me-1"></i> <?php echo e($time); ?> <i
                                    class="fa-solid fa-user-group ms-3 me-1"></i> <?php echo e($reservation->num_of_people); ?></div>
                            <div class="mt-1 d-flex align-items-center gap-2 flex-wrap">
                                <span class="text-dark fw-medium"><?php echo e($tableName); ?></span>
                                <span
                                    class="badge rounded-pill px-2 py-1 status-badge <?php echo e($statusBadgeClass($reservation->status)); ?>">
                                    <?php echo e($reservation->status); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted small mb-0">No reservations.</p>
                <?php endif; ?>
            </div>

            <div class="mt-4">
                <h6 class="fw-bold text-secondary mb-3 small text-uppercase" style="letter-spacing: 0.5px;">Canceled</h6>
                <div class="d-flex flex-column gap-3">
                    <?php $__empty_1 = true; $__currentLoopData = $cancelledReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $customer = $fullName($reservation);
                            $time = \Carbon\Carbon::parse($reservation->reservation_time)->format('H:i');
                        ?>
                        <div class="card p-3 border border-dashed rounded-4 bg-light opacity-75">
                            <div class="d-flex justify-content-between align-items-start mb-1">
                                <div class="fw-bold text-secondary"><?php echo e($customer); ?></div>
                                <span class="text-muted small"
                                    style="font-size: 11px;">RM<?php echo e(str_pad($reservation->id, 3, '0', STR_PAD_LEFT)); ?></span>
                            </div>
                            <div class="text-danger small fw-medium mb-2" style="font-size: 13px;">
                                <?php echo e($cancelledByLabel($reservation)); ?></div>
                            <div class="text-muted small" style="font-size: 13px;">
                                <i class="fa-regular fa-clock me-1"></i> <?php echo e($time); ?>

                                <i class="fa-solid fa-user-group ms-3 me-1"></i> <?php echo e($reservation->num_of_people); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted small mb-0">No canceled reservations.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="d-none d-md-flex flex-grow-1" style="overflow-x: auto;">
            <div class="bg-white p-3 d-flex flex-column gap-3" style="width: 320px; min-width: 320px; overflow-y: auto;">
                <div>
                    <h6 class="fw-bold text-dark mb-3">Reservations (<?php echo e($activeReservations->count()); ?>)</h6>
                    <div class="d-flex flex-column gap-2">
                        <?php $__empty_1 = true; $__currentLoopData = $activeReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $customer = $fullName($reservation);
                                $time = \Carbon\Carbon::parse($reservation->reservation_time)->format('H:i');
                                $tableName = $reservation->table->table_name ?? '-';
                            ?>
                            <div class="card p-3 border rounded-3 position-relative shadow-sm"
                                style="background-color: #ffffff; cursor: pointer;"
                                onclick="openReservationModal(<?php echo e($reservation->id); ?>, 'RM<?php echo e(str_pad($reservation->id, 3, '0', STR_PAD_LEFT)); ?>', <?php echo e(\Illuminate\Support\Js::from($customer)); ?>, '<?php echo e($time); ?>', <?php echo e(\Illuminate\Support\Js::from($durationLabel)); ?>, <?php echo e($reservation->num_of_people); ?>, <?php echo e(\Illuminate\Support\Js::from($tableName)); ?>, '<?php echo e($reservation->status); ?>')">
                                <span
                                    class="badge text-secondary border position-absolute top-0 end-0 mt-2 me-2 small fw-normal bg-light"
                                    style="font-size: 10px;">
                                    RM<?php echo e(str_pad($reservation->id, 3, '0', STR_PAD_LEFT)); ?>

                                </span>

                                <div class="fw-bold text-dark mb-1 pe-5"><?php echo e($customer); ?></div>

                                <div class="text-secondary small d-flex align-items-center gap-1">
                                    <i class="fa-regular fa-clock"></i> <?php echo e($time); ?>

                                    <i class="fa-solid fa-user-group ms-2"></i> <?php echo e($reservation->num_of_people); ?>

                                </div>

                                <div class="d-flex align-items-center gap-2 flex-wrap mt-1">
                                    <span class="text-secondary small"><?php echo e($tableName); ?></span>
                                    <span
                                        class="badge rounded-pill px-2 py-1 status-badge <?php echo e($statusBadgeClass($reservation->status)); ?>">
                                        <?php echo e($reservation->status); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted small mb-0">No reservations.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mt-2">
                    <h6 class="fw-bold text-secondary mb-3 small text-uppercase" style="letter-spacing: 0.5px;">Canceled
                    </h6>
                    <div class="d-flex flex-column gap-2">
                        <?php $__empty_1 = true; $__currentLoopData = $cancelledReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $customer = $fullName($reservation);
                                $time = \Carbon\Carbon::parse($reservation->reservation_time)->format('H:i');
                            ?>
                            <div class="card p-3 border border-dashed rounded-3 position-relative bg-light opacity-75">
                                <span class="text-muted position-absolute top-0 end-0 mt-2 me-2 small"
                                    style="font-size: 10px;">
                                    RM<?php echo e(str_pad($reservation->id, 3, '0', STR_PAD_LEFT)); ?>

                                </span>
                                <div class="fw-bold text-secondary mb-1 pe-5"><?php echo e($customer); ?></div>
                                <div class="text-danger small fw-medium"><?php echo e($cancelledByLabel($reservation)); ?></div>
                                <div class="text-muted small d-flex align-items-center gap-1 mt-1">
                                    <i class="fa-regular fa-clock"></i> <?php echo e($time); ?>

                                    <i class="fa-solid fa-user-group ms-2"></i> <?php echo e($reservation->num_of_people); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted small mb-0">No canceled reservations.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="flex-grow-1 bg-white p-3 d-flex flex-column gap-3" style="overflow-y: auto;">
                <div class="d-flex justify-content-between align-items-center px-1">
                    <a href="<?php echo e(route('restaurant.dashboard', ['date' => $date, 'start_time' => $prevStart])); ?>"
                        class="btn btn-chevron-custom btn-sm px-2 py-1">
                        <i class="fa-solid fa-chevron-left"></i>
                    </a>

                    <span class="fw-bold text-dark small" style="letter-spacing: 0.5px;">
                        Showing <?php echo e($displayDate->format('m/d')); ?>

                        <?php if($timeSlots): ?>
                            <?php echo e($currentStart); ?> - <?php echo e($showingEnd); ?>

                        <?php else: ?>
                            Closed
                        <?php endif; ?>
                    </span>

                    <a href="<?php echo e(route('restaurant.dashboard', ['date' => $date, 'start_time' => $nextStart])); ?>"
                        class="btn btn-chevron-custom btn-sm px-2 py-1">
                        <i class="fa-solid fa-chevron-right"></i>
                    </a>
                </div>

                <div class="table-responsive">
                    <?php if($isClosed): ?>
                        <div class="alert alert-light border text-center text-muted mb-0">This restaurant is closed on this
                            date.</div>
                    <?php elseif(empty($timeSlots)): ?>
                        <div class="alert alert-light border text-center text-muted mb-0">No displayable time slots.</div>
                    <?php else: ?>
                        <table class="table schedule-table align-middle mb-0">
                            <thead class="text-secondary small text-start custom-table-head">
                                <tr>
                                    <th class="table-name-cell"></th>
                                    <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="time-head-cell" style="font-weight: 600; padding-left: 8px;">
                                            <?php echo e($time); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="shadow-sm <?php echo e($table->is_active ? '' : 'disabled-table'); ?>">

                                        <td class="table-name-cell table-clickable border-top border-bottom border-start border-end"
                                            onclick="openEditModal(<?php echo e($table->id); ?>, <?php echo e(\Illuminate\Support\Js::from($table->table_name)); ?>, <?php echo e($table->capacity); ?>, <?php echo e($table->is_active ? 'false' : 'true'); ?>)">

                                            <div class="d-flex align-items-center gap-2 flex-nowrap">
                                                <div class="fw-bold text-truncate"><?php echo e($table->table_name); ?></div>

                                                <?php if (! ($table->is_active)): ?>
                                                    <span class="badge bg-light text-secondary border flex-shrink-0"
                                                        style="font-size: 10px;">
                                                        Inactive
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="text-muted" style="font-size: 11px;"><?php echo e($table->capacity); ?> seats
                                            </div>

                                        </td>

                                        <?php $currentColumn = 0; ?>

                                        <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($currentColumn >= $totalColumns): ?>
                                                <?php break; ?>
                                            <?php endif; ?>

                                            <?php
                                                $reservation = $table->reservations->first(function ($res) use ($time) {
                                                    return \Carbon\Carbon::parse($res->reservation_time)->format(
                                                        'H:i',
                                                    ) === $time;
                                                });
                                            ?>

                                            <?php if($reservation): ?>
                                                <?php
                                                    $colspan = (int) ceil($blockMinutes / 15);
                                                    if ($currentColumn + $colspan > $totalColumns) {
                                                        $colspan = $totalColumns - $currentColumn;
                                                    }
                                                    $currentColumn += $colspan;
                                                    $customer = $fullName($reservation);
                                                    $reservationTime = \Carbon\Carbon::parse(
                                                        $reservation->reservation_time,
                                                    )->format('H:i');
                                                ?>

                                                <td colspan="<?php echo e($colspan); ?>" class="p-1" style="height: 50px;">
                                                    <div class="rounded <?php echo e($reservationBlockClass($reservation->status)); ?>"
                                                        style="height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; font-size: 10px;"
                                                        onclick="openReservationModal(<?php echo e($reservation->id); ?>, 'RM<?php echo e(str_pad($reservation->id, 3, '0', STR_PAD_LEFT)); ?>', <?php echo e(\Illuminate\Support\Js::from($customer)); ?>, '<?php echo e($reservationTime); ?>', <?php echo e(\Illuminate\Support\Js::from($durationLabel)); ?>, <?php echo e($reservation->num_of_people); ?>, <?php echo e(\Illuminate\Support\Js::from($table->table_name)); ?>, '<?php echo e($reservation->status); ?>')">
                                                        <div class="fw-bold text-truncate" style="max-width: 90%;">
                                                            <?php echo e($customer); ?></div>
                                                        <div class="text-truncate"><?php echo e($reservation->num_of_people); ?>

                                                            guests</div>
                                                    </div>
                                                </td>
                                            <?php else: ?>
                                                <td class="border-top border-bottom border-end empty-slot">&nbsp;</td>
                                                <?php $currentColumn++; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                    <?php echo $__env->make('restaurants.dashboard.modals.edit_table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('restaurants.dashboard.modals.add_table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('restaurants.dashboard.modals.reservation_details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('restaurants.dashboard.modals.new_reservation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>

        <script>
            const tableUpdateUrlTemplate = <?php echo json_encode(route('restaurant.tables.update', ['table' => '__ID__']), 512) ?>;
            const tableDeleteUrlTemplate = <?php echo json_encode(route('restaurant.tables.destroy', ['table' => '__ID__']), 512) ?>;
            const reservationUpdateUrlTemplate = <?php echo json_encode(route('restaurant.reservations.update_status', ['reservation' => '__ID__']), 512) ?>;

            function openEditModal(id, name, capacity, isDisabled = false) {
                document.getElementById('tableIdInput').value = id;
                document.getElementById('tableNameInput').value = name;
                document.getElementById('tableCapacityInput').value = capacity;

                const form = document.getElementById('editTableForm');
                const methodInput = document.getElementById('editTableMethod');
                form.action = tableUpdateUrlTemplate.replace('__ID__', id);
                methodInput.value = 'PUT';

                if (document.getElementById('deleteTableAction')) {
                    document.getElementById('deleteTableAction').value = tableDeleteUrlTemplate.replace('__ID__', id);
                }

                const enableBtn = document.getElementById('status-enable-btn');
                const disableBtn = document.getElementById('status-disable-btn');
                const statusInput = document.getElementById('table-status-input');

                if (isDisabled) {
                    toggleStatus('disable');
                    document.getElementById('btnEnableTable')?.classList.remove('d-none');
                    document.getElementById('btnDisableTable')?.classList.add('d-none');
                } else {
                    toggleStatus('enable');
                    document.getElementById('btnDisableTable')?.classList.remove('d-none');
                    document.getElementById('btnEnableTable')?.classList.add('d-none');
                }

                hideConfirmView();
                new bootstrap.Modal(document.getElementById('editTableModal')).show();
            }

            function prepareTableDelete() {
                const deleteUrl = document.getElementById('deleteTableAction').value;
                const form = document.getElementById('editTableForm');
                const methodInput = document.getElementById('editTableMethod');
                form.action = deleteUrl;
                methodInput.value = 'DELETE';
            }

            function openReservationModal(reservationId, code, customer, time, duration, guests, table, status = 'confirmed') {
                document.getElementById('resIdDisplay').innerText = code;
                document.getElementById('resCustomerDisplay').innerText = customer;
                document.getElementById('resTimeDisplay').innerText = time;
                document.getElementById('resDurationDisplay').innerText = duration;
                document.getElementById('resGuestsDisplay').innerText = guests;
                document.getElementById('resTableDisplay').innerText = table;
                document.getElementById('resStatusDisplay').innerText = status;

                const form = document.getElementById('reservationStatusForm');
                form.action = reservationUpdateUrlTemplate.replace('__ID__', reservationId);

                document.getElementById('normalResActions').classList.toggle('d-none', status === 'completed' || status ===
                    'cancelled');
                document.getElementById('pendingResActions').classList.toggle('d-none', status !== 'pending');
                document.getElementById('confirmedResActions').classList.toggle('d-none', status !== 'confirmed');
                document.getElementById('completedResActions').classList.toggle('d-none', status !== 'completed' && status !==
                    'cancelled');

                hideResCancelConfirm();
                new bootstrap.Modal(document.getElementById('reservationDetailsModal')).show();
            }
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.restaurant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/hikari/Desktop/kredo-school-43rd_Batch-Pin-81/resources/views/restaurants/dashboard/index.blade.php ENDPATH**/ ?>